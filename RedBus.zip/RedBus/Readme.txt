Download Selenium : https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java/4.25.0
Download Driver : https://googlechromelabs.github.io/chrome-for-testing/#stable
